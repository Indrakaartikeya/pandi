import React, { useState } from 'react';
import { Save, ChevronLeft, IndianRupee, Cpu, Clock, MapPin } from 'lucide-react';
import { AppSettings } from '../types';
import { motion } from 'motion/react';

interface SettingsProps {
  settings: AppSettings;
  onSave: (settings: AppSettings) => void;
  onBack: () => void;
}

export default function Settings({ settings, onSave, onBack }: SettingsProps) {
  const [formData, setFormData] = useState<AppSettings>(settings);

  const handleSave = () => {
    onSave(formData);
    onBack();
  };

  return (
    <div className="flex flex-col h-full bg-studio-bg text-studio-text">
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-6 py-6 pb-32">
        <SettingItem 
          label="Procurement Unit Rate (₹/kWh)" 
          icon={<IndianRupee className="w-5 h-5 text-studio-accent" />}
          value={formData.perUnitRate}
          onChange={(v) => setFormData({ ...formData, perUnitRate: parseFloat(v) })}
        />
        
        <SettingItem 
          label="Export Credit Rate (₹/kWh)" 
          icon={<IndianRupee className="w-5 h-5 text-studio-warning" />}
          value={formData.exportRate}
          onChange={(v) => setFormData({ ...formData, exportRate: parseFloat(v) })}
        />

        <SettingItem 
          label="Solar Array Capacity (kW)" 
          icon={<Cpu className="w-5 h-5 text-studio-accent" />}
          value={formData.panelCapacityKw}
          onChange={(v) => setFormData({ ...formData, panelCapacityKw: parseFloat(v) })}
        />

        <div className="flex flex-col gap-2">
          <label className="text-[10px] uppercase font-bold text-gray-600 tracking-wider flex items-center gap-2">
            <Clock className="w-3 h-3" /> Peak Window Trigger Time
          </label>
          <input 
            type="time" 
            value={formData.peakSunTime}
            onChange={(e) => setFormData({ ...formData, peakSunTime: e.target.value })}
            className="w-full bg-studio-panel border border-studio-border p-4 font-mono text-white outline-none focus:border-studio-accent"
          />
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-[10px] uppercase font-bold text-gray-600 tracking-wider flex items-center gap-2">
            <MapPin className="w-3 h-3" /> Regional Profile
          </label>
          <select 
            value={formData.weatherRegion}
            onChange={(e) => setFormData({ ...formData, weatherRegion: e.target.value })}
            className="w-full bg-studio-panel border border-studio-border p-4 font-mono text-white outline-none focus:border-studio-accent appearance-none"
          >
            <option>South India</option>
            <option>North India</option>
            <option>West Coast</option>
            <option>East Coast</option>
          </select>
        </div>

        <div className="flex flex-col gap-4 bg-studio-panel border border-studio-border p-4 mt-2">
          <div className="flex flex-col gap-2 mb-2">
            <div className="flex items-center justify-between">
              <label className="text-[10px] uppercase font-bold text-studio-accent tracking-widest font-mono">Appliance Repository</label>
              <button 
                onClick={() => {
                  const id = Date.now().toString();
                  setFormData({
                    ...formData,
                    appliances: [
                      ...formData.appliances,
                      { id, name: 'New Device', powerKw: 0.1, count: 1 }
                    ]
                  });
                }}
                className="text-[9px] bg-studio-accent text-white px-2 py-0.5 font-bold uppercase tracking-widest"
              >
                Add_New
              </button>
            </div>
            <span className="text-[8px] text-gray-600 font-mono italic">Tap name to edit. Power is in kilowatts (kW).</span>
          </div>
          
          {formData.appliances.map((app, idx) => (
            <div key={app.id} className="flex flex-col gap-1 pb-3 border-b border-studio-border last:border-0 last:pb-0">
              <div className="flex items-center justify-between">
                <div className="flex flex-col flex-1">
                  <input 
                    type="text"
                    value={app.name}
                    onChange={(e) => {
                      const newApps = [...formData.appliances];
                      newApps[idx] = { ...app, name: e.target.value };
                      setFormData({ ...formData, appliances: newApps });
                    }}
                    className="bg-transparent border-0 text-[10px] font-bold text-white uppercase tracking-tight p-0 focus:ring-0 w-full"
                  />
                  <div className="flex items-center gap-2">
                    <span className="text-[8px] text-gray-500 font-mono">Power:</span>
                    <input 
                      type="number"
                      step="0.01"
                      value={isNaN(app.powerKw) ? '' : app.powerKw}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        const newApps = [...formData.appliances];
                        newApps[idx] = { ...app, powerKw: isNaN(val) ? 0 : val };
                        setFormData({ ...formData, appliances: newApps });
                      }}
                      className="bg-studio-bg border border-studio-border rounded px-1 text-[8px] text-studio-accent font-mono w-12 focus:border-studio-accent outline-none"
                    />
                    <span className="text-[8px] text-gray-500 font-mono">kW</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => {
                      const newApps = formData.appliances.filter((_, i) => i !== idx);
                      setFormData({ ...formData, appliances: newApps });
                    }}
                    className="text-[8px] text-gray-600 hover:text-studio-warning uppercase font-bold"
                  >
                    Delete
                  </button>
                  <ApplianceControl 
                    label="" 
                    value={app.count} 
                    onChange={(v) => {
                      const newApps = [...formData.appliances];
                      newApps[idx] = { ...app, count: v };
                      setFormData({ ...formData, appliances: newApps });
                    }} 
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-3 mt-4">
          <label className="text-[10px] uppercase font-bold text-gray-600 tracking-wider">Repository Maintenance</label>
          <button 
            onClick={() => alert('Logs exported as system.log.csv')}
            className="w-full bg-studio-panel border border-studio-border p-4 text-[10px] font-bold uppercase hover:bg-studio-accent/10 transition-colors tracking-widest text-gray-400"
          >
            DUMP DATABASE TO CSV
          </button>
        </div>

        <motion.button 
          whileTap={{ scale: 0.95 }}
          onClick={handleSave}
          className="mt-8 bg-studio-accent text-white font-black uppercase text-sm tracking-widest p-5 flex items-center justify-center gap-3 shadow-2xl shadow-studio-accent/20"
        >
          <Save className="w-5 h-5" />
          Update Parameters
        </motion.button>

        <p className="text-[10px] text-gray-700 text-center uppercase tracking-[0.2em] mt-8 font-mono">
          SYSTEM_VERSION: 1.0.87-STABLE
        </p>
      </div>
    </div>
  );
}

function SettingItem({ label, icon, value, onChange }: { label: string, icon: React.ReactNode, value: number, onChange: (v: string) => void }) {
  return (
    <div className="flex flex-col gap-2">
      <label className="text-[10px] uppercase font-bold text-gray-600 tracking-wider flex items-center gap-2">
        {label}
      </label>
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2">{icon}</div>
        <input 
          type="number" 
          step="any"
          value={isNaN(value) ? '' : value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-studio-panel border border-studio-border p-4 pl-12 font-mono text-white outline-none focus:border-studio-accent"
        />
      </div>
    </div>
  );
}

function ApplianceControl({ label, value, onChange }: { label: string, value: number, onChange: (v: number) => void }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs font-medium text-gray-400">{label}</span>
      <div className="flex items-center gap-4">
        <button 
          onClick={() => onChange(Math.max(0, value - 1))}
          className="w-8 h-8 flex items-center justify-center bg-studio-bg border border-studio-border text-studio-accent"
        >
          -
        </button>
        <span className="text-sm font-mono font-bold w-4 text-center">{value}</span>
        <button 
          onClick={() => onChange(value + 1)}
          className="w-8 h-8 flex items-center justify-center bg-studio-bg border border-studio-border text-studio-accent"
        >
          +
        </button>
      </div>
    </div>
  );
}
