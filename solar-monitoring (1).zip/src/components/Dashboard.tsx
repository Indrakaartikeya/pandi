import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sun, Battery, ArrowUpRight, ArrowDownLeft, Zap, ClipboardList, TrendingUp, Settings as SettingsIcon, IndianRupee, Thermometer, Cloud } from 'lucide-react';
import { EnergyLog, AppSettings } from '../types';
import { cn } from '../lib/utils';
import { getAutoStatsFromWeather } from '../services/geminiService';

interface DashboardProps {
  logs: EnergyLog[];
  settings: AppSettings;
  onNavigate: (view: 'home' | 'log' | 'report' | 'settings') => void;
  aiTip: string;
}

export default function Dashboard({ logs, settings, onNavigate, aiTip }: DashboardProps) {
  const [realTimeWeather, setRealTimeWeather] = useState<{ 
    temp: number, 
    weather: 'Sunny' | 'Cloudy', 
    description: string,
    generation: number,
    consumption: number,
    thermalLoss?: number
  } | null>(null);
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [coords, setCoords] = useState<{ lat: number, lng: number } | undefined>();

  useEffect(() => {
    // Get geolocation
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => console.log("Geo blocked", err)
      );
    }
  }, []);

  const latNorm = coords ? Math.round(coords.lat * 10) / 10 : null;
  const lngNorm = coords ? Math.round(coords.lng * 10) / 10 : null;

  const fetchWeatherData = async () => {
    setIsSyncing(true);
    try {
      const stats = await getAutoStatsFromWeather(settings, coords);
      setRealTimeWeather(stats);
      setLastSync(new Date());
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    fetchWeatherData();
    const interval = setInterval(fetchWeatherData, 60 * 60 * 1000); // Hourly sync
    return () => clearInterval(interval);
  }, [latNorm, lngNorm, settings.weatherRegion, settings.panelCapacityKw]);

  const latestLog = logs[logs.length - 1];
  
  // Calculate Savings & Costs
  const calculateFinancials = () => {
    if (logs.length === 0) return { cost: 0, savings: 0, usagePercent: 0, coveragePercent: 0 };
    
    let totalSavings = 0;
    let totalCost = 0;
    let totalSolarUsed = 0;
    
    logs.forEach(log => {
      const net = log.generationKwh - log.consumptionKwh;
      totalCost += log.consumptionKwh * settings.perUnitRate;
      
      const solarUsed = Math.min(log.generationKwh, log.consumptionKwh);
      totalSolarUsed += solarUsed;

      if (net >= 0) {
        totalSavings += (log.consumptionKwh * settings.perUnitRate) + (net * settings.exportRate);
      } else {
        totalSavings += (log.generationKwh * settings.perUnitRate);
      }
    });

    const totalGen = logs.reduce((acc, l) => acc + l.generationKwh, 0);
    const totalCons = logs.reduce((acc, l) => acc + l.consumptionKwh, 0);
    
    const usagePercent = totalGen > 0 ? (totalSolarUsed / totalGen) * 100 : 0;
    const coveragePercent = totalCons > 0 ? (totalSolarUsed / totalCons) * 100 : 0;

    return { cost: totalCost, savings: totalSavings, usagePercent, coveragePercent };
  };

  const { cost, savings, usagePercent, coveragePercent } = calculateFinancials();
  const netStatus = latestLog ? latestLog.generationKwh - latestLog.consumptionKwh : 0;
  
  // Simplified Meter metrics
  const tickCount = 11; // Fewer ticks for mobile clarity
  const liveGenKw = realTimeWeather ? Number(realTimeWeather.generation) || 0 : 0;
  const liveConsKw = realTimeWeather ? Number(realTimeWeather.consumption) || 0 : 0;
  
  // Coverage calculations
  const liveCoverage = liveConsKw > 0 ? Math.min(100, (liveGenKw / liveConsKw) * 100) : 0;
  
  const sysCapacity = Number(settings.panelCapacityKw) || 1;
  const netFlow = liveGenKw - liveConsKw;

  // Flow scaling for needle
  const flowScale = Math.min(Math.max(netFlow * 25, -100), 100); 
  const balanceRotation = (flowScale / 100) * 90; 

  // Load Breakdown - Dynamic based on active demand
  const totalPotentialLoad = settings.appliances.reduce((acc, app) => acc + (Number(app.powerKw) * Number(app.count)), 0) || 1;
  const loadProfile = settings.appliances.map(app => {
    const power = Number(app.powerKw) || 0;
    const count = Number(app.count) || 0;
    const weight = (power * count) / totalPotentialLoad;
    const liveAppLoad = liveConsKw * weight;
    const val = (liveConsKw > 0) ? (liveAppLoad * 100) / (power * count || 1) : 0;
    
    return {
      name: app.name,
      kw: liveAppLoad,
      value: isNaN(val) ? 0 : val,
      color: app.id === 'ac' ? '#3D7EDB' : app.id === 'fridge' ? '#27AE60' : app.id === 'fan' ? '#F2994A' : '#9B51E0'
    };
  }).slice(0, 4);

  return (
    <div className="flex flex-col gap-6 p-4 bg-studio-bg h-full overflow-y-auto pb-40">
      {/* ANALOG SPEEDOMETER GAUGE */}
      <div className="relative flex flex-col items-center justify-center pt-12 pb-16 bg-studio-panel border border-studio-border group overflow-visible">
        {/* Subtle Tech Background */}
        <div className="absolute inset-0 opacity-[0.012] pointer-events-none z-0">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,var(--color-studio-accent)_0%,transparent_80%)]" />
        </div>

        {/* Global Live Bar */}
        <div className="flex items-center justify-between w-full px-5 pb-10 relative z-10">
           <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-studio-accent animate-pulse shadow-[0_0_8px_var(--color-studio-accent)]" />
              <span className="text-[9px] font-black text-white/40 uppercase tracking-widest font-mono">Live_Data</span>
           </div>
           <div className="flex items-center gap-2 bg-studio-bg/60 px-2 py-1 rounded border border-studio-border/30" onClick={() => fetchWeatherData()}>
              <Thermometer className={cn("w-3 h-3 text-studio-warning", isSyncing && "animate-spin")} />
              <span className="text-[10px] font-black text-white leading-none">
                {realTimeWeather ? `${Math.round(realTimeWeather.temp)}°C` : '--°C'}
              </span>
           </div>
        </div>

        <div className="relative w-full flex flex-col items-center select-none mx-auto pb-12">
          <div className="relative w-[280px] h-[160px] sm:w-[320px] sm:h-[180px]">
            {/* Dial Ticks */}
            <div className="absolute top-[140px] sm:top-[160px] left-1/2 -translate-x-1/2 w-full h-[280px] sm:h-[320px] pointer-events-none">
              {Array.from({ length: tickCount }).map((_, i) => {
                const angle = -90 + (i * (180 / (tickCount - 1))); 
                const isMajor = i % 5 === 0;
                return (
                  <div 
                    key={i}
                    className="absolute top-0 left-1/2 -translate-x-1/2 h-[140px] sm:h-[160px] origin-bottom pointer-events-none"
                    style={{ transform: `rotate(${angle}deg)` }}
                  >
                    <div className={cn(
                      "w-[1px] mx-auto",
                      isMajor ? "h-3 bg-white/20" : "h-1 bg-white/5"
                    )}></div>
                  </div>
                );
              })}
            </div>

            <svg viewBox="0 0 300 150" className="absolute top-[10px] left-1/2 -translate-x-1/2 w-[260px] h-[130px] sm:w-[300px] sm:h-[150px]">
              <defs>
                <linearGradient id="exportGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#27AE60" stopOpacity="0.1" />
                  <stop offset="100%" stopColor="#27AE60" stopOpacity="0.8" />
                </linearGradient>
                <linearGradient id="importGradient" x1="100%" y1="0%" x2="0%" y2="0%">
                  <stop offset="0%" stopColor="#EB5757" stopOpacity="0.1" />
                  <stop offset="100%" stopColor="#EB5757" stopOpacity="0.8" />
                </linearGradient>
              </defs>
              
              <path 
                d="M 20 150 A 130 130 0 0 1 280 150"
                fill="transparent" 
                stroke="rgba(255,255,255,0.02)" 
                strokeWidth="16" 
              />
              
              {netFlow < 0 && (
                <motion.path
                  d="M 150 20 A 130 130 0 0 0 20 150"
                  fill="transparent"
                  stroke="url(#importGradient)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={Math.PI * 130 / 2}
                  initial={{ strokeDashoffset: Math.PI * 130 / 2 }}
                  animate={{ strokeDashoffset: (Math.PI * 130 / 2) * (1 - Math.abs(flowScale) / 100) }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                />
              )}

              {netFlow > 0 && (
                <motion.path
                  d="M 150 20 A 130 130 0 0 1 280 150"
                  fill="transparent"
                  stroke="url(#exportGradient)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={Math.PI * 130 / 2}
                  initial={{ strokeDashoffset: Math.PI * 130 / 2 }}
                  animate={{ strokeDashoffset: (Math.PI * 130 / 2) * (1 - Math.abs(flowScale) / 100) }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                />
              )}
            </svg>
            
            {/* Central Reading */}
            <div className="absolute top-[80px] left-0 w-full flex flex-col items-center justify-center z-20">
               <motion.div className="flex items-baseline justify-center font-mono">
                 <span className="text-4xl sm:text-5xl font-black tracking-tighter leading-none text-white">
                   {realTimeWeather ? Math.abs(netFlow).toFixed(2) : '---'}
                 </span>
                 <span className="text-[10px] font-bold text-gray-700 ml-1">kW</span>
               </motion.div>

               <div className="flex items-center gap-8 mt-5 pt-3 border-t border-white/5">
                  <div className="flex flex-col items-center">
                     <Sun className="w-2.5 h-2.5 text-studio-accent mb-0.5" />
                     <span className="text-[10px] font-mono font-black text-white/50">{liveGenKw.toFixed(1)}</span>
                  </div>
                  <div className="flex flex-col items-center">
                     <Zap className="w-2.5 h-2.5 text-studio-warning mb-0.5" />
                     <span className="text-[10px] font-mono font-black text-white/50">{liveConsKw.toFixed(1)}</span>
                  </div>
               </div>
            </div>

            <motion.div 
              className="absolute bottom-0 left-1/2 w-[2px] h-[150px] sm:h-[170px] origin-bottom -translate-x-[1px] z-30"
              animate={{ rotate: balanceRotation }} 
              transition={{ duration: 2, ease: [0.16, 1, 0.3, 1] }}
            >
               <div className="w-full h-full bg-white/10 rounded-full shadow-[0_0_15px_rgba(255,255,255,0.1)]"></div>
            </motion.div>

            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-8 bg-studio-bg border-2 border-studio-panel rounded-full z-40 translate-y-1/2">
               <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent"></div>
            </div>
          </div>
        </div>
      </div>

      {/* WEATHER CONTEXT STRIP */}
      <AnimatePresence>
        {realTimeWeather && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="group relative flex items-center justify-between gap-3 px-4 py-3 bg-studio-panel border border-studio-border rounded backdrop-blur-sm mx-1"
          >
            <div className="flex items-center gap-3 min-w-0">
              <Cloud className={cn("w-4 h-4", realTimeWeather.weather === 'Sunny' ? "text-studio-accent" : "text-gray-500")} />
              <div className="flex flex-col min-w-0 uppercase font-mono">
                 <div className="flex items-baseline gap-2 overflow-hidden whitespace-nowrap">
                    <span className="text-[10px] font-black text-white">{realTimeWeather.temp}°C</span>
                    <span className="text-[8px] font-bold text-white/30 truncate">{realTimeWeather.description}</span>
                 </div>
              </div>
            </div>

            {realTimeWeather.thermalLoss !== undefined && (
              <div className="flex flex-col items-end shrink-0">
                 <span className="text-[7px] font-black text-gray-500 mb-1">THERMAL_LOSS</span>
                 <div className="flex items-center gap-2">
                    <div className="w-12 h-0.5 bg-studio-bg rounded-full overflow-hidden">
                      <div className="h-full bg-studio-warning/50" style={{ width: `${realTimeWeather.thermalLoss}%` }} />
                    </div>
                    <span className="text-[9px] font-black text-studio-warning font-mono">
                      -{realTimeWeather.thermalLoss.toFixed(1)}%
                    </span>
                 </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* LOAD BREAKDOWN - GRID OPTIMIZATION */}
      <div className="grid grid-cols-2 gap-4">
        {loadProfile.map((item) => (
          <div key={item.name} className="bg-studio-panel border border-studio-border p-4 relative overflow-hidden group hover:border-studio-accent/30 transition-colors">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest font-mono truncate mr-2">{item.name}</span>
                <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: item.color }} />
              </div>
              <div className="flex flex-col">
                <div className="flex items-baseline gap-1">
                  <span className="text-xl font-mono font-black text-white leading-none">{item.kw.toFixed(2)}</span>
                  <span className="text-[8px] text-gray-600 font-bold uppercase tracking-widest">kW</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[8px] font-bold text-gray-700 uppercase tracking-tighter">Utilization</span>
                  <span className="text-[10px] font-mono font-black text-white/40">{item.value.toFixed(0)}%</span>
                </div>
              </div>
            </div>
            {/* Subtle Progress Track */}
            <div className="absolute bottom-0 left-0 w-full h-[3px] bg-studio-bg opacity-20" />
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${item.value}%` }}
              className="absolute bottom-0 left-0 h-[3px] transition-all duration-1000 shadow-[0_0_10px_rgba(0,0,0,0.5)]" 
              style={{ backgroundColor: item.color }} 
            />
          </div>
        ))}
      </div>

      {/* FINANCIAL OVERVIEW - ECONOMIC YIELD */}
      <div className="grid grid-cols-2 gap-4">
        <div className="relative bg-studio-panel p-5 border border-studio-border overflow-hidden group">
          <div className="absolute top-0 right-0 p-1 opacity-[0.05] group-hover:opacity-[0.1] transition-opacity">
            <IndianRupee className="w-16 h-16 text-studio-warning rotate-12" />
          </div>
          <div className="relative z-10 flex flex-col items-start">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-1 h-3 bg-studio-warning rounded-full" />
              <span className="text-[10px] font-black uppercase text-gray-500 tracking-[0.2em] font-mono leading-none">Gross_Cost</span>
            </div>
            <div className="flex items-baseline gap-1.5 mt-1">
               <span className="text-sm font-bold text-gray-600 font-mono">₹</span>
               <span className="text-3xl font-black text-white tracking-tighter font-mono leading-tight">
                 {cost.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
               </span>
            </div>
            <span className="text-[7px] font-bold text-studio-warning/60 uppercase mt-2 tracking-widest font-mono">Grid_Liability_Log</span>
          </div>
        </div>
        
        <div className="relative bg-studio-panel p-5 border border-studio-border overflow-hidden group">
          <div className="absolute top-0 right-0 p-1 opacity-[0.05] group-hover:opacity-[0.1] transition-opacity">
            <TrendingUp className="w-16 h-16 text-studio-success -rotate-12" />
          </div>
          <div className="relative z-10 flex flex-col items-start">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-1 h-3 bg-studio-success rounded-full" />
              <span className="text-[10px] font-black uppercase text-gray-500 tracking-[0.2em] font-mono leading-none">Net_Yield</span>
            </div>
            <div className="flex items-baseline gap-1.5 mt-1">
               <span className="text-sm font-bold text-studio-success font-mono">₹</span>
               <span className="text-3xl font-black text-studio-success tracking-tighter font-mono leading-tight">
                 {savings.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
               </span>
            </div>
            <span className="text-[7px] font-bold text-studio-success/60 uppercase mt-2 tracking-widest font-mono">Solar_Retention_Log</span>
          </div>
        </div>
      </div>

      {/* AI TIP BOX */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-studio-panel border-l-2 border-studio-accent p-4"
      >
        <div className="flex items-center gap-2 mb-2">
          <Zap className="w-4 h-4 text-studio-accent" />
          <span className="text-[10px] font-bold uppercase text-studio-accent font-mono">Kernel Insight</span>
        </div>
        <p className="text-sm text-studio-text leading-relaxed font-medium">
          {aiTip}
        </p>
      </motion.div>

      {/* QUICK STATS */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard 
          label="Generation" 
          value={`${latestLog?.generationKwh.toFixed(1) || '0.0'} kWh`}
          icon={<Sun className="w-4 h-4 text-studio-accent" />}
          color="text-studio-accent"
        />
        <StatCard 
          label="Consumption" 
          value={`${latestLog?.consumptionKwh.toFixed(1) || '0.0'} kWh`}
          icon={<Battery className="w-4 h-4 text-studio-success" />}
          color="text-studio-success"
        />
      </div>

      {/* REAL-TIME PERFORMANCE QUOTIENT */}
      <div className="bg-studio-panel border border-studio-border p-5 relative overflow-visible">
        <div className="flex items-center justify-between mb-4">
           <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase text-studio-accent font-mono tracking-widest mb-1.5">Live Solar Coverage</span>
              <span className="text-[7px] text-gray-500 font-mono uppercase">Current_Load_Met_By_Solar</span>
           </div>
           <div className="text-2xl font-black text-white font-mono leading-none">
              {liveCoverage.toFixed(0)}%
           </div>
        </div>
        <div className="w-full h-1.5 bg-studio-bg rounded-full overflow-hidden">
           <motion.div 
             initial={{ width: 0 }}
             animate={{ width: `${liveCoverage}%` }}
             className="h-full bg-studio-accent"
           />
        </div>
      </div>

      {/* OVERALL PERFORMANCE */}
      <div className="bg-studio-panel border border-studio-border p-5 relative overflow-visible">
        <div className="grid grid-cols-2 gap-6 mb-5">
           <div className="flex flex-col">
              <span className="text-[9px] font-bold uppercase text-gray-500 font-mono tracking-widest leading-none mb-2">Self-Consumption</span>
              <div className="text-xl font-black text-white font-mono">
                {usagePercent.toFixed(1)}%
              </div>
              <span className="text-[7px] text-studio-accent/60 font-mono uppercase mt-1">Solar_Used_Log</span>
           </div>
           <div className="flex flex-col text-right">
              <span className="text-[9px] font-bold uppercase text-gray-500 font-mono tracking-widest leading-none mb-2">Solar Fraction</span>
              <div className="text-xl font-black text-white font-mono">
                {coveragePercent.toFixed(1)}%
              </div>
              <span className="text-[7px] text-studio-success/60 font-mono uppercase mt-1">Load_Covered_Log</span>
           </div>
        </div>
        
        <div className="space-y-3">
          <div className="w-full h-1.5 bg-studio-bg rounded-full overflow-hidden">
             <motion.div 
               initial={{ width: 0 }}
               animate={{ width: `${usagePercent}%` }}
               className="h-full bg-studio-accent"
             />
          </div>
          <div className="w-full h-1.5 bg-studio-bg rounded-full overflow-hidden">
             <motion.div 
               initial={{ width: 0 }}
               animate={{ width: `${coveragePercent}%` }}
               className="h-full bg-studio-success"
             />
          </div>
        </div>
        
        <div className="mt-3 flex justify-between">
           <span className="text-[8px] font-bold text-gray-700 uppercase">System Stats</span>
           <span className="text-[8px] font-bold text-gray-500 uppercase">Lifetime Data</span>
        </div>
      </div>

      {/* NET STATUS BANNER */}
      <div className={cn(
        "p-4 flex items-center justify-between border-y border-studio-border bg-studio-panel mb-8",
        netStatus > 0 ? "border-l-4 border-l-studio-success" : 
        netStatus < 0 ? "border-l-4 border-l-studio-warning" : 
        "border-l-4 border-l-studio-accent"
      )}>
        <div className="flex items-center gap-3">
          {netStatus > 0 ? <ArrowUpRight className="text-studio-success" /> : <ArrowDownLeft className="text-studio-warning" />}
          <div>
            <p className="text-[10px] uppercase text-gray-500 font-bold">Process Status</p>
            <p className={cn("font-bold text-sm tracking-tight", netStatus > 0 ? "text-studio-success" : netStatus < 0 ? "text-studio-warning" : "text-white")}>
              {netStatus > 0 ? 'EXPORTING' : netStatus < 0 ? 'DEFICIT' : 'STABLE'} ({Math.abs(netStatus).toFixed(2)} units)
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) {
  return (
    <div className="bg-studio-panel p-4 border border-studio-border">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-[10px] uppercase font-bold text-gray-600 tracking-wider font-mono">{label}</span>
      </div>
      <div className={cn("text-xl font-bold font-mono", color)}>{value}</div>
    </div>
  );
}

function ActionButton({ label, icon, onClick, className }: { label: string, icon: React.ReactNode, onClick: () => void, className?: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn("flex flex-col items-center justify-center gap-2 p-6 transition-all active:scale-95 group", className)}
    >
      <div className="scale-125 group-hover:scale-110 transition-transform">{icon}</div>
      <span className="text-[10px] font-bold uppercase mt-1 tracking-widest">{label}</span>
    </button>
  );
}
