import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, AreaChart, Area } from 'recharts';
import { EnergyLog, AppSettings } from '../types';
import { TrendingUp, IndianRupee, Download, FileText } from 'lucide-react';
import { getEnergyForecast } from '../services/geminiService';
import { cn } from '../lib/utils';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

interface SavingsChartProps {
  logs: EnergyLog[];
  settings: AppSettings;
  onBack: () => void;
}

export default function SavingsChart({ logs, settings, onBack }: SavingsChartProps) {
  const [forecast, setForecast] = useState<{ date: string, predictedGen: number, predictedCons: number }[]>([]);
  const [isLoadingForecast, setIsLoadingForecast] = useState(false);

  useEffect(() => {
    const fetchForecast = async () => {
      console.log("Fetching forecast for logs:", logs.length);
      setIsLoadingForecast(true);
      try {
        const data = await getEnergyForecast(logs, settings);
        console.log("Received forecast data:", data);
        setForecast(data || []);
      } catch (e) {
        console.error("Forecast fetch failed", e);
      } finally {
        setIsLoadingForecast(false);
      }
    };
    fetchForecast();
  }, [logs, settings]);

  const chartData = logs.slice(-30).map(log => {
    const gen = Number(log.generationKwh) || 0;
    const cons = Number(log.consumptionKwh) || 0;
    const net = gen - cons;
    
    // actualSavings: money saved + money earned from exports
    const savings = net > 0 
      ? (net * settings.exportRate) + (cons * settings.perUnitRate)
      : (gen * settings.perUnitRate);
    
    // generationValue: the gross market value of the energy produced
    const genValue = gen * settings.perUnitRate;
    
    return {
      date: new Date(log.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
      netKwh: isNaN(net) ? 0 : net,
      savings: isNaN(savings) ? 0 : Math.round(savings),
      genValue: isNaN(genValue) ? 0 : Math.round(genValue)
    };
  });

  const totalSavings = chartData.reduce((acc, d) => acc + d.savings, 0);
  
  const totalGen = logs.reduce((acc, l) => acc + l.generationKwh, 0);
  const totalCons = logs.reduce((acc, l) => acc + l.consumptionKwh, 0);
  const selfConsumptionRatio = totalGen > 0 ? (Math.min(totalGen, totalCons) / totalGen) * 100 : 0;
  const solarDependency = totalCons > 0 ? (Math.min(totalGen, totalCons) / totalCons) * 100 : 0;

  const downloadPDFReport = () => {
    const doc = new jsPDF();
    const timestamp = new Date().toLocaleString();

    // Title
    doc.setFontSize(20);
    doc.setTextColor(61, 126, 219); // Studio Accent Color
    doc.text('SURYA-SHAKTI ENERGY REPORT', 14, 22);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Generated on: ${timestamp}`, 14, 30);
    doc.text(`Region: ${settings.weatherRegion || 'Standard'}`, 14, 35);

    // Summary Section
    doc.setFontSize(14);
    doc.setTextColor(0);
    doc.text('System Performance Summary', 14, 45);
    
    const summaryData = [
      ['Total Logs', logs.length.toString()],
      ['Total Savings (Projected)', `Rs. ${totalSavings.toLocaleString('en-IN')}`],
      ['Lifetime Generation', `${totalGen.toFixed(2)} kWh`],
      ['Lifetime Consumption', `${totalCons.toFixed(2)} kWh`],
      ['Self-Consumption Ratio', `${selfConsumptionRatio.toFixed(1)}%`],
      ['Solar Autonomy', `${solarDependency.toFixed(1)}%`],
      ['Grid Rate', `Rs. ${settings.perUnitRate}/unit`]
    ];

    autoTable(doc, {
      startY: 50,
      head: [['Metric', 'Value']],
      body: summaryData,
      theme: 'grid',
      headStyles: { fillColor: [61, 126, 219] },
    });

    // History Table
    doc.setFontSize(14);
    doc.text('Detailed Energy History', 14, (doc as any).lastAutoTable.finalY + 15);

    const tableLogs = [...logs].reverse().map(log => {
      const net = log.generationKwh - log.consumptionKwh;
      const savings = net > 0 
        ? (net * settings.exportRate) + (log.consumptionKwh * settings.perUnitRate)
        : (log.generationKwh * settings.perUnitRate);
      
      return [
        new Date(log.date).toLocaleDateString('en-IN'),
        log.generationKwh.toFixed(2),
        log.consumptionKwh.toFixed(2),
        net.toFixed(2),
        Math.round(savings).toString()
      ];
    });

    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 20,
      head: [['Date', 'Gen (kWh)', 'Cons (kWh)', 'Net (kWh)', 'Est. Savings (Rs.)']],
      body: tableLogs,
      theme: 'striped',
      headStyles: { fillColor: [31, 36, 45] },
    });

    doc.save(`surya-shakti-report-${new Date().toISOString().split('T')[0]}.pdf`);
  };

  return (
    <div className="flex flex-col h-full bg-studio-bg text-studio-text">
      <div className="flex-1 p-4 flex flex-col gap-6 overflow-y-auto pb-32">
        {/* TOTAL SAVINGS CARD */}
        <div className="bg-studio-accent p-6 text-white border border-studio-accent/30 relative overflow-hidden group">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 opacity-70" />
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80 font-mono">Net Processed Savings</span>
            </div>
            <div className="text-4xl font-black flex items-baseline gap-1 tracking-tighter">
              <span className="text-2xl font-bold opacity-60">₹</span>
              {totalSavings.toLocaleString('en-IN')}
            </div>
          </div>
          {/* Subtle design element */}
          <div className="absolute -right-4 -bottom-4 opacity-10 group-hover:scale-110 transition-transform">
            <TrendingUp size={120} />
          </div>
        </div>

        {/* CHART CONTAINER */}
        <div className="bg-studio-panel p-4 border border-studio-border">
          <h3 className="text-[10px] uppercase font-mono font-bold text-gray-600 mb-6 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <IndianRupee className="w-3 h-3" /> FINANCIAL_ANALYSIS_LOG
            </div>
            <span className="text-[8px] opacity-40 lowercase">values in ₹</span>
          </h3>
          <div className="h-[280px] w-full relative">
            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <XAxis 
                  dataKey="date" 
                  stroke="#2a2e3a" 
                  fontSize={9} 
                  tickLine={false} 
                  axisLine={false}
                  fontFamily="JetBrains Mono"
                />
                <YAxis 
                  stroke="#2a2e3a"
                  fontSize={8}
                  tickLine={false}
                  axisLine={false}
                  fontFamily="JetBrains Mono"
                />
                <Tooltip 
                  cursor={{ fill: 'rgba(255,255,255,0.03)' }}
                  contentStyle={{ 
                    backgroundColor: '#12151C', 
                    border: '1px solid #1F242D', 
                    borderRadius: '0', 
                    fontSize: '11px',
                    fontFamily: 'JetBrains Mono'
                  }}
                  itemStyle={{ padding: '2px 0' }}
                  formatter={(value: any, name: string) => {
                    if (name === "genValue") return [`₹${value}`, "GROSS_VALUE"];
                    if (name === "savings") return [`₹${value}`, "NET_SAVINGS"];
                    return [value, name];
                  }}
                />
                <CartesianGrid strokeDasharray="3 3" stroke="#1F242D" vertical={false} />
                <Bar dataKey="genValue" fill="#CF8E6D" fillOpacity={0.6} radius={[2, 2, 0, 0]} barSize={12} />
                <Bar dataKey="savings" fill="#3D7EDB" radius={[2, 2, 0, 0]} barSize={18} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          {/* LEGEND */}
          <div className="grid grid-cols-2 gap-4 mt-8 border-t border-white/5 pt-6 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-studio-accent rounded-sm shrink-0"></div>
              <div className="flex flex-col">
                <span className="text-[9px] uppercase font-mono font-bold text-white/70 tracking-widest leading-none">Net_Savings</span>
                <span className="text-[7px] uppercase font-mono text-gray-600 mt-1.5">Realized value</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-[#CF8E6D] opacity-60 rounded-sm shrink-0"></div>
              <div className="flex flex-col">
                <span className="text-[9px] uppercase font-mono font-bold text-white/40 tracking-widest leading-none">Market_Value</span>
                <span className="text-[7px] uppercase font-mono text-gray-600 mt-1.5">Gross potential</span>
              </div>
            </div>
          </div>
        </div>

        {/* PERFORMANCE METRICS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
          <div className="bg-studio-panel border border-studio-border p-4">
            <span className="text-[8px] font-bold text-gray-600 uppercase block mb-1 font-mono">Self-Consumption</span>
            <div className="text-xl font-black text-white">{selfConsumptionRatio.toFixed(1)}%</div>
            <div className="text-[7px] text-gray-700 mt-1 uppercase font-mono tracking-tighter">% of total solar used at source</div>
          </div>
          <div className="bg-studio-panel border border-studio-border p-4">
            <span className="text-[8px] font-bold text-gray-600 uppercase block mb-1 font-mono">Solar Autonomy</span>
            <div className="text-xl font-black text-studio-accent">{solarDependency.toFixed(1)}%</div>
            <div className="text-[7px] text-gray-700 mt-1 uppercase font-mono tracking-tighter">% of household load met by solar</div>
          </div>
        </div>

        {/* 7-DAY AI FORECAST */}
        <div className="bg-studio-panel border border-studio-border p-5 relative overflow-hidden mt-2">
            <div className="flex items-center justify-between mb-6">
                <div className="flex flex-col">
                    <div className="flex items-center gap-2 mb-1">
                        <TrendingUp className="w-3 h-3 text-studio-accent" />
                        <span className="text-[10px] font-black uppercase text-studio-accent font-mono tracking-widest">7-Day AI Projection</span>
                    </div>
                    <span className="text-[7px] text-gray-500 font-mono uppercase">Neural_Forecast_Engine_Active</span>
                </div>
                {isLoadingForecast && (
                    <div className="w-4 h-4 border-2 border-studio-accent border-t-transparent rounded-full animate-spin" />
                )}
            </div>

            {forecast.length > 0 ? (
                <div className="h-[285px] w-full mt-4 relative border border-white/[0.02]">
                    <ResponsiveContainer width="100%" height="100%" key={`forecast-chart-${forecast.length}`}>
                        <AreaChart data={forecast} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                            <defs>
                                <linearGradient id="colorGen" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#3D7EDB" stopOpacity={0.4}/>
                                    <stop offset="95%" stopColor="#3D7EDB" stopOpacity={0}/>
                                </linearGradient>
                                <linearGradient id="colorCons" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#EB5757" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#EB5757" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#1F242D" vertical={false} />
                            <XAxis 
                                dataKey="date" 
                                fontSize={8} 
                                tickLine={false} 
                                axisLine={false}
                                stroke="#666"
                                tickFormatter={(val) => {
                                  try {
                                    if (!val) return "";
                                    const d = new Date(val);
                                    if (isNaN(d.getTime())) return val;
                                    return `${d.getDate()}/${d.getMonth() + 1}`;
                                  } catch (e) {
                                    return val;
                                  }
                                }}
                            />
                            <YAxis 
                                stroke="#444"
                                fontSize={7}
                                tickLine={false}
                                axisLine={false}
                                width={25}
                                tickFormatter={(val) => `₹${(val * settings.perUnitRate).toFixed(0)}`}
                            />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#12151C', border: '1px solid #1F242D', borderRadius: '4px', fontSize: '9px', fontFamily: 'JetBrains Mono' }}
                                itemStyle={{ padding: '0' }}
                                formatter={(value: any, name: string) => [
                                  `₹${(Number(value) * settings.perUnitRate).toFixed(0)}`,
                                  name === "predictedGen" ? "PROJ_GEN" : "PROJ_LOAD"
                                ]}
                            />
                            <Area 
                                type="monotone" 
                                dataKey="predictedGen" 
                                stroke="#3D7EDB" 
                                fillOpacity={1} 
                                fill="url(#colorGen)" 
                                strokeWidth={2}
                                isAnimationActive={false}
                            />
                            <Area 
                                type="monotone" 
                                dataKey="predictedCons" 
                                stroke="#EB5757" 
                                fillOpacity={1} 
                                fill="url(#colorCons)" 
                                strokeWidth={2} 
                                strokeDasharray="5 5"
                                isAnimationActive={false}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                    <div className="mt-4 grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                        <div className="flex items-center gap-2">
                            <div className="w-3 h-1 bg-[#3D7EDB]"></div>
                            <span className="text-[8px] font-bold font-mono text-gray-500 uppercase tracking-tighter">PROJECTED_GEN</span>
                        </div>
                        <div className="flex items-center gap-2 text-right justify-end">
                            <span className="text-[8px] font-bold font-mono text-gray-500 uppercase tracking-tighter">PROJECTED_LOAD</span>
                            <div className="w-3 h-1 border-b-2 border-dashed border-[#EB5757]"></div>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="h-[200px] flex items-center justify-center border border-dashed border-studio-border bg-studio-bg/30">
                    <span className="text-[9px] font-mono text-gray-600 tracking-widest animate-pulse">
                        {isLoadingForecast ? 'CALCULATING_PROJECTIONS...' : 'WAITING_FOR_DATA_RELAY...'}
                    </span>
                </div>
            )}
        </div>

        <div className="mt-4 p-4 border border-dashed border-studio-border bg-studio-bg opacity-50">
           <p className="text-[9px] font-mono leading-tight text-gray-600">
             ANALYTICS_KERNEL_V1: Performance derived from {logs.length} synced data points. Standard deviation within expected solar radiance variance.
           </p>
        </div>

        {/* DOWNLOAD REPORT BUTTON */}
        <button 
          onClick={downloadPDFReport}
          className="mt-6 w-full flex items-center justify-center gap-3 bg-studio-panel border border-studio-border p-5 group hover:bg-studio-accent transition-all active:scale-[0.98]"
        >
          <div className="p-3 bg-studio-bg group-hover:bg-white/10 rounded border border-studio-border group-hover:border-white/20">
            <Download className="w-5 h-5 text-studio-accent group-hover:text-white" />
          </div>
          <div className="flex flex-col items-start leading-none">
            <span className="text-[10px] font-black uppercase tracking-widest text-gray-500 group-hover:text-white/60 mb-1 font-mono">System_Protocol_09</span>
            <span className="text-sm font-black uppercase tracking-tighter text-white">Generate PDF Archive</span>
          </div>
          <FileText className="w-4 h-4 ml-auto opacity-20 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
        </button>
      </div>
    </div>
  );
}
