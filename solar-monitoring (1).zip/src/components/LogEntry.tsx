import React, { useState, useEffect } from 'react';
import { Sun, Cloud, Save, ChevronLeft, Zap, RefreshCw, Thermometer } from 'lucide-react';
import { EnergyLog, AppSettings } from '../types';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';
import { getAutoStatsFromWeather } from '../services/geminiService';

interface LogEntryProps {
  settings: AppSettings;
  onSave: (log: EnergyLog) => void;
  onBack: () => void;
  onNavigate: (view: 'home' | 'log' | 'report' | 'settings') => void;
}

export default function LogEntry({ settings, onSave, onBack, onNavigate }: LogEntryProps) {
  const [generation, setGeneration] = useState<string>('');
  const [consumption, setConsumption] = useState<string>('');
  const [weather, setWeather] = useState<'Sunny' | 'Cloudy'>('Sunny');
  const [isSyncing, setIsSyncing] = useState(false);
  const [currentTemp, setCurrentTemp] = useState<number | null>(null);
  const [coords, setCoords] = useState<{ lat: number, lng: number } | undefined>();
  
  // Appliance usage for workload calculation
  const [activeHours, setActiveHours] = useState<Record<string, number>>(
    settings.appliances.reduce((acc, app) => ({ ...acc, [app.id]: app.id === 'fridge' ? 24 : 0 }), {})
  );

  useEffect(() => {
    let load = 0;
    settings.appliances.forEach(app => {
      const hours = Number(activeHours[app.id]) || 0;
      const power = Number(app.powerKw) || 0;
      const count = Number(app.count) || 0;
      load += hours * power * count;
    });
    setConsumption(isNaN(load) ? '0.0' : load.toFixed(1));
  }, [activeHours, settings.appliances]);

  const handleAutoSync = async () => {
    setIsSyncing(true);
    try {
      const stats = await getAutoStatsFromWeather(settings, coords);
      const genValue = stats.dailyGenerationKwh || stats.generation;
      const consValue = stats.dailyConsumptionKwh || stats.consumption;
      
      setGeneration(isNaN(genValue) ? '0.0' : genValue.toFixed(1));
      setConsumption(isNaN(consValue) ? '0.0' : consValue.toFixed(1));
      setWeather(stats.weather);
      setCurrentTemp(stats.temp);
    } catch (error) {
      console.error("Sync failed", error);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSimulate = (type: 'Sunny' | 'Cloudy') => {
    setWeather(type);
    // Simulation logic: Sunny = full capacity * 5 peak hours, Cloudy = 40% of that
    const cap = Number(settings.panelCapacityKw) || 0;
    const baseKwh = cap * 5;
    const estimate = type === 'Sunny' ? baseKwh : baseKwh * 0.4;
    setGeneration(isNaN(estimate) ? '0.0' : estimate.toFixed(1));
  };

  const handleSave = () => {
    if (!generation || !consumption) return;
    onSave({
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      generationKwh: parseFloat(generation),
      consumptionKwh: parseFloat(consumption),
      weatherCondition: weather
    });
    onBack();
  };

  return (
    <div className="flex flex-col h-full bg-studio-bg">
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-8 py-8 pb-32">
        {/* AUTO SYNC BUTTON */}
        <button 
          onClick={handleAutoSync}
          disabled={isSyncing}
          className="w-full bg-studio-panel border border-studio-accent/30 p-4 flex items-center justify-between group hover:bg-studio-accent/5 transition-colors"
        >
          <div className="flex flex-col items-start">
            <span className="text-[10px] font-bold text-studio-accent uppercase tracking-widest">Autonomous Sync</span>
            <span className="text-xs text-gray-500 font-medium">Auto-fill based on thermal data</span>
          </div>
          <div className="flex items-center gap-3">
            {currentTemp !== null && (
              <div className="flex items-center gap-1 text-studio-success font-mono text-xs font-bold">
                <Thermometer className="w-3 h-3" />
                {currentTemp}°C
              </div>
            )}
            <RefreshCw className={cn("w-5 h-5 text-studio-accent", isSyncing && "animate-spin")} />
          </div>
        </button>

        {/* SIMULATION TOGGLE */}
        <div className="flex flex-col gap-3">
          <label className="text-[10px] uppercase font-bold text-gray-600 tracking-wider">Environmental Simulation</label>
          <div className="flex gap-2">
            <button 
              onClick={() => handleSimulate('Sunny')}
              className={cn(
                "flex-1 flex flex-col items-center gap-2 p-4 border transition-all",
                weather === 'Sunny' ? "bg-studio-accent border-studio-accent text-white" : "bg-studio-panel border-studio-border text-gray-500"
              )}
            >
              <Sun className="w-8 h-8" />
              <span className="text-[10px] font-bold uppercase tracking-widest">High Irradiance</span>
            </button>
            <button 
              onClick={() => handleSimulate('Cloudy')}
              className={cn(
                "flex-1 flex flex-col items-center gap-2 p-4 border transition-all",
                weather === 'Cloudy' ? "bg-studio-accent/20 border-studio-accent text-white" : "bg-studio-panel border-studio-border text-gray-500"
              )}
            >
              <Cloud className="w-8 h-8" />
              <span className="text-[10px] font-bold uppercase tracking-widest">Overcast</span>
            </button>
          </div>
        </div>

        {/* GENERATION INPUT */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <label className="text-[10px] uppercase font-bold text-gray-600 tracking-wider">Input Energy (kWh)</label>
            <div className="flex gap-1">
               <button onClick={() => setGeneration((settings.panelCapacityKw * 2).toFixed(1))} className="text-[8px] bg-studio-bg border border-studio-border text-gray-500 px-1.5 py-0.5 font-mono">2h</button>
               <button onClick={() => setGeneration((settings.panelCapacityKw * 4).toFixed(1))} className="text-[8px] bg-studio-bg border border-studio-border text-gray-500 px-1.5 py-0.5 font-mono">4h</button>
               <button onClick={() => setGeneration((settings.panelCapacityKw * 6).toFixed(1))} className="text-[8px] bg-studio-bg border border-studio-border text-gray-500 px-1.5 py-0.5 font-mono">6h</button>
            </div>
          </div>
          <div className="relative">
            <Zap className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-studio-accent" />
            <input 
              type="number"
              step="0.1"
              value={generation}
              onChange={(e) => setGeneration(e.target.value)}
              placeholder="0.0"
              className="w-full bg-studio-panel border border-studio-border p-4 pl-12 text-2xl font-mono text-white focus:border-studio-accent outline-none"
            />
          </div>
        </div>

        {/* APPLIANCE LOAD WORKSHEET */}
        <div className="bg-studio-panel border border-studio-border p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex flex-col">
              <label className="text-[10px] uppercase font-bold text-studio-accent tracking-widest font-mono">Load_Wizard</label>
              <span className="text-[8px] text-gray-500 font-mono mt-0.5">ESTIMATE_CONSUMPTION_WIZARD</span>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => onNavigate('settings')}
                className="text-[9px] border border-studio-border text-gray-400 px-3 py-1 font-bold uppercase tracking-widest hover:text-white transition-colors"
                id="btn-manage-apps"
              >
                Repo
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            {settings.appliances.length > 0 ? (
              settings.appliances.map(app => (
                <ApplianceLogEntryRow 
                  key={app.id}
                  icon={app.name.slice(0, 3).toUpperCase()} 
                  label={app.name} 
                  hours={Number(activeHours[app.id]) || 0} 
                  onHoursChange={(v: number) => { setActiveHours(prev => ({ ...prev, [app.id]: v })); }} 
                />
              ))
            ) : (
              <div className="flex flex-col items-center justify-center p-6 border border-dashed border-studio-border bg-studio-bg/30">
                <span className="text-[10px] text-gray-600 font-mono uppercase">No_Appliances_Available</span>
                <button 
                  onClick={() => onNavigate('settings')}
                  className="mt-2 text-[9px] text-studio-accent underline font-bold"
                >
                  Configure_Repository
                </button>
              </div>
            )}
          </div>
        </div>

        {/* CONSUMPTION INPUT */}
        <div className="flex flex-col gap-3">
          <label className="text-[10px] uppercase font-bold text-gray-600 tracking-wider">Demand Energy (kWh)</label>
          <div className="relative">
            <Zap className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-800" />
            <input 
              type="number"
              value={consumption}
              onChange={(e) => setConsumption(e.target.value)}
              placeholder="0.0"
              className="w-full bg-studio-panel border border-studio-border p-4 pl-12 text-2xl font-mono text-white focus:border-studio-accent outline-none"
            />
          </div>
        </div>

        {/* SAVE BUTTON */}
        <motion.button 
          whileTap={{ scale: 0.95 }}
          onClick={handleSave}
          disabled={!generation || !consumption}
          className="mt-auto bg-studio-accent text-white font-black uppercase text-sm tracking-widest py-5 flex items-center justify-center gap-3 disabled:opacity-30 disabled:grayscale transition-all"
        >
          <Save className="w-5 h-5" />
          Commit Data to Repo
        </motion.button>
      </div>
    </div>
  );
}

function ApplianceLogEntryRow({ icon, label, hours, onHoursChange }: { icon: string, label: string, hours: number, onHoursChange: (v: number) => void, key?: React.Key }) {
  return (
    <div className="flex items-center justify-between p-2.5 bg-studio-bg border border-studio-border/50 hover:border-studio-accent/30 transition-colors group">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 flex items-center justify-center bg-studio-panel border border-studio-border text-[9px] font-black text-studio-accent font-mono group-hover:bg-studio-accent group-hover:text-white transition-all">
          {icon}
        </div>
        <div className="flex flex-col">
          <span className="text-xs font-semibold text-gray-300">{label}</span>
          <span className="text-[8px] text-gray-600 font-mono uppercase tracking-tighter">Usage_Timeline</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button 
          onClick={() => onHoursChange(Math.max(0, hours - 1))}
          className="w-7 h-7 flex items-center justify-center bg-studio-panel border border-studio-border text-xs text-white hover:border-white transition-colors"
        >
          -
        </button>
        <div className="flex flex-col items-center w-14">
          <span className="text-[10px] font-mono font-bold text-studio-accent">{hours}h</span>
          <div className="w-full h-0.5 bg-studio-border/50 mt-0.5 overflow-hidden">
             <div className="h-full bg-studio-accent transition-all duration-300" style={{ width: `${isNaN(hours) ? 0 : (hours / 24) * 100}%` }}></div>
          </div>
        </div>
        <button 
          onClick={() => onHoursChange(Math.min(24, hours + 1))}
          className="w-7 h-7 flex items-center justify-center bg-studio-panel border border-studio-border text-xs text-white hover:border-white transition-colors"
        >
          +
        </button>
      </div>
    </div>
  );
}
