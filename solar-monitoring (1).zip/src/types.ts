/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface EnergyLog {
  id: string;
  date: string; // ISO string
  generationKwh: number;
  consumptionKwh: number;
  weatherCondition: 'Sunny' | 'Cloudy';
}

export interface ApplianceConfig {
  id: string;
  name: string;
  powerKw: number;
  count: number;
}

export interface AppSettings {
  perUnitRate: number; // ₹/unit
  exportRate: number; // ₹/unit
  panelCapacityKw: number;
  peakSunTime: string; // HH:mm
  weatherRegion: string;
  appliances: ApplianceConfig[];
}

export interface SavingsRecord {
  id: string;
  date: string;
  netKwh: number;
  savingsRupees: number;
  exportUnits: number;
}
