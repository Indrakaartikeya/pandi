import { GoogleGenAI } from "@google/genai";
import { EnergyLog, AppSettings } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

let tipCache: { key: string; data: string; timestamp: number } | null = null;
const TIP_CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours cache for tips

let quotaCooldownUntil = Number(localStorage.getItem('ss_quota_cooldown')) || 0;
const QUOTA_COOLDOWN_DURATION = 30 * 60 * 1000; // 30 mins cooldown if 429 hit

function setQuotaCooldown() {
  quotaCooldownUntil = Date.now() + QUOTA_COOLDOWN_DURATION;
  localStorage.setItem('ss_quota_cooldown', quotaCooldownUntil.toString());
}

export async function generateEnergyTip(logs: EnergyLog[], settings: AppSettings): Promise<string> {
  if (logs.length === 0) {
    return "Start logging your energy data to get personalized solar saving tips!";
  }

  // Use a more stable cache key: just the last log count and region
  const cacheKey = `logs-${logs.length}-${settings.weatherRegion}-${settings.panelCapacityKw}`;
  const cached = localStorage.getItem('ss_tip_cache');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (parsed.key === cacheKey && (Date.now() - parsed.timestamp < TIP_CACHE_DURATION)) {
        return parsed.data;
      }
    } catch (e) {
      localStorage.removeItem('ss_tip_cache');
    }
  }

  // Quota Guard
  if (Date.now() < quotaCooldownUntil) {
    return "Optimize your energy flows by running heavy loads when solar radiance is at its zenith (11 AM - 3 PM).";
  }

  const recentLogs = logs.slice(-3);
  const averageGen = recentLogs.reduce((acc, log) => acc + log.generationKwh, 0) / recentLogs.length;
  const averageCons = recentLogs.reduce((acc, log) => acc + log.consumptionKwh, 0) / recentLogs.length;
  const applianceList = settings.appliances.map(a => `${a.name}(x${a.count})`).join(', ');

  const prompt = `
    You are Surya-Shakti AI, an expert in solar energy optimization for households in India.
    Based on the following data, provide a 2-sentence personalized tip for today.
    
    Context:
    - User Region: ${settings.weatherRegion}
    - Solar Capacity: ${settings.panelCapacityKw}kW
    - Appliances: ${applianceList}
    
    Performance (last 3 entries):
    - Avg Generation: ${averageGen.toFixed(2)} kWh
    - Avg Consumption: ${averageCons.toFixed(2)} kWh
    - Net Balance: ${(averageGen - averageCons).toFixed(2)} kWh
    
    Guidelines: 
    - Be concise (max 2 sentences).
    - Focus on shifting load to peak-sun hours or saving battery.
    - Sound encouraging and practical.
    - Include specific times if relevant (e.g., 10 AM to 3 PM).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt
    });
    
    const tip = response.text || "Optimization active.";
    localStorage.setItem('ss_tip_cache', JSON.stringify({ key: cacheKey, data: tip, timestamp: Date.now() }));
    return tip;
  } catch (error) {
    if (error instanceof Error && (error.message.includes("429") || error.message.includes("quota"))) {
      setQuotaCooldown();
    } else {
      console.error("Gemini Error:", error);
    }
    
    const balance = averageGen - averageCons;
    if (balance > 0) {
      return `With a healthy ${balance.toFixed(2)} kWh surplus, today is the perfect time to run heavy appliances like your washing machine or pump during the peak solar window of 10 AM to 3 PM.`;
    } else {
      return `Your consumption is slightly high compared to generation. Shifting non-essential laundry or cooling to morning hours (9 AM - 11 AM) will maximize your direct solar usage.`;
    }
  }
}

export async function getEnergyForecast(logs: EnergyLog[], settings: AppSettings): Promise<{ date: string, predictedGen: number, predictedCons: number }[]> {
  if (logs.length === 0) return [];

  const recentLogs = logs.slice(-14); // Use last 2 weeks for trend
  const applianceList = settings.appliances.map(a => `${a.name}(x${a.count})`).join(', ');

  const prompt = `
    You are Surya-Shakti Forecasting Engine.
    Based on the historical energy data and user settings, predict the energy consumption and generation for the NEXT 7 DAYS.
    
    User Settings:
    - Region: ${settings.weatherRegion}
    - Solar Capacity: ${settings.panelCapacityKw}kW
    - Appliances: ${applianceList}
    
    Historical Data (last 14 days):
    ${recentLogs.map(l => `Date: ${l.date}, Gen: ${l.generationKwh}kWh, Cons: ${l.consumptionKwh}kWh`).join('\n')}
    
    Task:
    Predict generation based on typical solar radiance patterns for ${settings.weatherRegion} in May (current month per system).
    Predict consumption based on the historical trend and typical household behavior.
    
    Return ONLY a JSON array of 7 objects:
    [
      { "date": "YYYY-MM-DD", "predictedGen": number, "predictedCons": number },
      ...
    ]
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text || "";
    console.log("Forecast RAW output:", text);
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    const jsonText = jsonMatch ? jsonMatch[0] : text;
    const items = JSON.parse(jsonText);
    
    if (Array.isArray(items) && items.length > 0) {
      return items.slice(0, 7).map(item => ({
        ...item,
        predictedGen: Number(item.predictedGen) || 0,
        predictedCons: Number(item.predictedCons) || 0
      }));
    }
    throw new Error("Invalid forecast format received");
  } catch (error) {
    console.error("Forecast Error:", error);
    // Guaranteed fallback forecast based on trend
    const lastLog = logs[logs.length - 1];
    const baseGen = lastLog?.generationKwh || settings.panelCapacityKw * 4;
    const baseCons = lastLog?.consumptionKwh || 10;
    
    return Array.from({ length: 7 }).map((_, i) => ({
      date: new Date(Date.now() + (i + 1) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      predictedGen: Number((baseGen * (0.85 + Math.random() * 0.3)).toFixed(2)),
      predictedCons: Number((baseCons * (0.9 + Math.random() * 0.2)).toFixed(2))
    }));
  }
}

let weatherCache: { key: string, data: any, timestamp: number } | null = null;
const CACHE_DURATION = 1 * 60 * 60 * 1000; // 1 hour cache as requested

export async function getAutoStatsFromWeather(settings: AppSettings, coords?: { lat: number, lng: number }): Promise<{ 
  temp: number, 
  weather: 'Sunny' | 'Cloudy', 
  description: string, 
  generation: number, 
  consumption: number, 
  dailyGenerationKwh: number,
  dailyConsumptionKwh: number,
  thermalLoss: number 
}> {
  // Coarsen coords to 0.1 degrees (~11km precision) for city-wise grouping
  const latR = coords ? Math.round(coords.lat * 10) / 10 : null;
  const lngR = coords ? Math.round(coords.lng * 10) / 10 : null;
  const locationStr = latR !== null ? `City_Zone: ${latR},${lngR}` : `Region: ${settings.weatherRegion}`;
  const applianceStr = (settings.appliances || []).length; // Just use count to avoid cache busting on small metadata changes
  const cacheKey = `${locationStr}-${settings.panelCapacityKw}-${applianceStr}`;

  const cached = localStorage.getItem('ss_weather_cache');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (parsed.key === cacheKey && (Date.now() - parsed.timestamp < CACHE_DURATION)) {
        return parsed.data;
      }
    } catch (e) {
      localStorage.removeItem('ss_weather_cache');
    }
  }

  // Quota Guard fallback
  if (Date.now() < quotaCooldownUntil) {
     return getSimulatedFallback(settings);
  }
  
    const prompt = `
    You are the Google Weather & Energy Bridge for Surya-Shakti.
    Current Location: ${locationStr}
    Local Time: ${new Date().toLocaleTimeString()}
    System Peak Capacity: ${settings.panelCapacityKw}kW
    Appliances in system: ${applianceStr}

    Task:
    1. Search for current weather (Temp, Sky condition) at this location.
    2. Calculate REALISTIC INSTANTANEOUS energy metrics:
       - currentGenerationKw: Peak solar output is ${settings.panelCapacityKw}kW. At this time of day and weather, how many kW are being generated? (e.g. at noon on a sunny day, it should be 80-100% of peak capacity).
       - currentConsumptionKw: Based on the appliances and typical household demand for this time/temp, what is the current kW load?
    
    Return ONLY a JSON object:
    {
      "temp": number,
      "weather": "Sunny" | "Cloudy",
      "description": string,
      "nominalGenerationKw": number, // The generation BEFORE thermal/atmospheric losses
      "currentConsumptionKw": number,
      "estimatedDailyGenerationKwh": number,
      "estimatedDailyConsumptionKwh": number
    }
  `;

  try {
    const response = await ai.models.generateContent({ 
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }] 
      }
    });
    
    // Extract JSON more robustly
    const text = response.text || "";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    const jsonText = jsonMatch ? jsonMatch[0] : text;
    const data = JSON.parse(jsonText);
    
    // Physical Adjustment: Temperature Impact on Solar Efficiency
    // Standard PV panels lose ~0.4% efficiency for every degree above 25°C
    const ambientTemp = Number(data.temp) || 25;
    const cellTemp = ambientTemp + (data.weather === 'Sunny' ? 25 : 10); // Standard NOCT (Nominal Operating Cell Temperature)
    const deltaT = cellTemp - 25;
    const tempCoefficient = -0.004; 
    const efficiencyFactor = Math.max(0.4, 1 + (deltaT * tempCoefficient));
    
    const nominalLiveGen = Number(data.nominalGenerationKw) || 0;
    const nominalDailyGen = Number(data.estimatedDailyGenerationKwh) || (settings.panelCapacityKw * (data.weather === 'Sunny' ? 5.0 : 2.5));
    
    const thermalAdjustedLiveGen = nominalLiveGen * efficiencyFactor;
    const thermalAdjustedDailyGen = nominalDailyGen * efficiencyFactor;

    const formattedData = {
      temp: ambientTemp,
      generation: thermalAdjustedLiveGen,
      consumption: Math.max(0.1, Number(data.currentConsumptionKw) || 0.5),
      dailyGenerationKwh: thermalAdjustedDailyGen,
      dailyConsumptionKwh: Number(data.estimatedDailyConsumptionKwh) || (Number(data.currentConsumptionKw) * 10),
      description: data.description || "Active Sky Monitoring",
      weather: data.weather || 'Sunny',
      thermalLoss: Math.abs((1 - efficiencyFactor) * 100)
    };

    localStorage.setItem('ss_weather_cache', JSON.stringify({ key: cacheKey, data: formattedData, timestamp: Date.now() }));
    return formattedData;
  } catch (error) {
    if (error instanceof Error && (error.message.includes("429") || error.message.includes("quota"))) {
      setQuotaCooldown();
    } else {
      console.error("Weather Bridge Error:", error);
    }
    return getSimulatedFallback(settings);
  }
}

function getSimulatedFallback(settings: AppSettings) {
  // Semi-randomized fallback to make UI feel alive
  const hour = new Date().getHours();
  const isDay = hour > 6 && hour < 18;
  
  // Realistic Solar Curve: Peak at 13 (1 PM)
  const baseGenRaw = isDay ? settings.panelCapacityKw * Math.max(0, Math.sin((hour - 6) * Math.PI / 11)) : 0;
  const weather = Math.random() > 0.4 ? 'Sunny' as const : 'Cloudy' as const;
  const cloudFactor = weather === 'Sunny' ? 0.95 : 0.4;
  const generation = baseGenRaw * cloudFactor;

  const dailyGenKwh = settings.panelCapacityKw * (weather === 'Sunny' ? 5.2 : 2.5);
  const temp = 26 + (Math.sin((hour - 6) * Math.PI / 12) * 8) + (Math.random() * 2);
  
  return { 
    temp: Math.round(temp * 10) / 10,
    generation: Math.max(0, generation), 
    consumption: 0.8 + (Math.random() * 1.5), 
    dailyGenerationKwh: dailyGenKwh,
    dailyConsumptionKwh: 10 + Math.random() * 5,
    weather: weather, 
    description: "Atmospheric Simulation Active",
    thermalLoss: Math.max(2, (temp - 25) * 0.4) 
  };
}
