import { EnergyLog, AppSettings } from "../types";

const LOGS_KEY = 'surya_shakti_logs';
const SETTINGS_KEY = 'surya_shakti_settings';

const DEFAULT_SETTINGS: AppSettings = {
  perUnitRate: 7,
  exportRate: 3,
  panelCapacityKw: 5,
  peakSunTime: '11:00',
  weatherRegion: 'South India',
  appliances: [
    { id: 'ac', name: 'Air Conditioner', powerKw: 1.5, count: 1 },
    { id: 'fridge', name: 'Refrigerator', powerKw: 0.1, count: 1 },
    { id: 'tv', name: 'Television', powerKw: 0.1, count: 1 },
    { id: 'fan', name: 'Ceiling Fan', powerKw: 0.07, count: 4 },
    { id: 'light', name: 'Lighting Unit', powerKw: 0.02, count: 8 }
  ]
};

export const db = {
  getLogs: (): EnergyLog[] => {
    const data = localStorage.getItem(LOGS_KEY);
    return data ? JSON.parse(data) : [];
  },
  
  saveLog: (log: EnergyLog) => {
    const logs = db.getLogs();
    const existingIndex = logs.findIndex(l => l.date.split('T')[0] === log.date.split('T')[0]);
    if (existingIndex > -1) {
      logs[existingIndex] = log;
    } else {
      logs.push(log);
    }
    localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
  },
  
  getSettings: (): AppSettings => {
    const data = localStorage.getItem(SETTINGS_KEY);
    if (!data) return DEFAULT_SETTINGS;
    try {
      const parsed = JSON.parse(data);
      // Migration/Safety check: Ensure appliances is an array
      const appliances = Array.isArray(parsed.appliances) ? parsed.appliances : DEFAULT_SETTINGS.appliances;
      return {
        ...DEFAULT_SETTINGS,
        ...parsed,
        appliances
      };
    } catch {
      return DEFAULT_SETTINGS;
    }
  },
  
  saveSettings: (settings: AppSettings) => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }
};
