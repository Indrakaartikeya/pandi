/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { db } from './services/db';
import { generateEnergyTip } from './services/geminiService';
import { EnergyLog, AppSettings } from './types';
import Dashboard from './components/Dashboard';
import LogEntry from './components/LogEntry';
import Settings from './components/Settings';
import SavingsChart from './components/SavingsChart';
import { Sun, TrendingUp, ClipboardList, Settings as SettingsIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

type View = 'home' | 'log' | 'report' | 'settings';

export default function App() {
  const [view, setView] = useState<View>('home');
  const [logs, setLogs] = useState<EnergyLog[]>([]);
  const [settings, setSettings] = useState<AppSettings>(db.getSettings());
  const [aiTip, setAiTip] = useState<string>("Running heavy appliances between 11 AM and 3 PM maximizing solar usage.");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initial data load
    const savedLogs = db.getLogs();
    setLogs(savedLogs);
    
    // Simulate App Cold Start (<2s)
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    // Fetch AI Tip
    generateEnergyTip(savedLogs, settings).then(setAiTip);

    return () => clearTimeout(timer);
  }, []);

  const handleSaveLog = (log: EnergyLog) => {
    db.saveLog(log);
    const updatedLogs = [...logs, log];
    setLogs(updatedLogs);
    // Refresh AI tip after log
    generateEnergyTip(updatedLogs, settings).then(setAiTip);
  };

  const handleSaveSettings = (newSettings: AppSettings) => {
    db.saveSettings(newSettings);
    setSettings(newSettings);
  };

  if (isLoading) {
    return (
      <div className="flex h-[100dvh] flex-col items-center justify-center bg-studio-bg gap-6">
        <motion.div
          animate={{ scale: [1, 1.1, 1], rotate: [0, 90, 180, 270, 360] }}
          transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
        >
          <Sun className="w-20 h-20 text-studio-accent drop-shadow-[0_0_15px_rgba(61,126,219,0.3)]" />
        </motion.div>
        <div className="flex flex-col items-center gap-1">
          <h1 className="text-3xl font-black text-studio-accent tracking-tighter uppercase">Surya-Shakti</h1>
          <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Initializing Immersive Studio</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-[100dvh] w-full max-w-md mx-auto bg-studio-bg text-studio-text font-sans selection:bg-studio-accent selection:text-white shadow-2xl relative overflow-hidden border-x border-studio-border flex-col">
      {/* APP HEADER */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-studio-border bg-studio-bg/80 backdrop-blur-md z-50">
        <div className="flex items-center gap-2">
          <Sun className="w-5 h-5 text-studio-accent" />
          <span className="text-sm font-black uppercase tracking-tighter">Surya-Shakti</span>
        </div>
        <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">v1.2.0_Stable</div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div 
              key="home" 
              initial={{ opacity: 0, scale: 0.98 }} 
              animate={{ opacity: 1, scale: 1 }} 
              exit={{ opacity: 0, scale: 0.98 }}
              className="w-full h-full"
            >
              <Dashboard 
                logs={logs} 
                settings={settings} 
                aiTip={aiTip}
                onNavigate={setView} 
              />
            </motion.div>
          )}

          {view === 'log' && (
            <motion.div 
              key="log" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: 20 }}
              className="w-full h-full"
            >
              <LogEntry 
                settings={settings} 
                onSave={handleSaveLog} 
                onBack={() => setView('home')} 
                onNavigate={setView}
              />
            </motion.div>
          )}

          {view === 'settings' && (
            <motion.div 
              key="settings" 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: 20 }}
              className="w-full h-full"
            >
              <Settings 
                settings={settings} 
                onSave={handleSaveSettings} 
                onBack={() => setView('home')} 
              />
            </motion.div>
          )}

          {view === 'report' && (
            <motion.div 
              key="report" 
              initial={{ opacity: 0, scale: 0.9 }} 
              animate={{ opacity: 1, scale: 1 }} 
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full h-full"
            >
              <SavingsChart 
                logs={logs} 
                settings={settings} 
                onBack={() => setView('home')} 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* BOTTOM NAVIGATION */}
      <nav className="flex items-center justify-around bg-studio-panel border-t border-studio-border py-4 px-6 z-50">
        <NavButton active={view === 'home'} icon={<TrendingUp />} label="Dashboard" onClick={() => setView('home')} />
        <NavButton active={view === 'report'} icon={<ClipboardList />} label="Analysis" onClick={() => setView('report')} />
        <NavButton active={view === 'log'} icon={<Sun className="bg-studio-accent rounded-full p-1 text-white" />} label="Log" onClick={() => setView('log')} />
        <NavButton active={view === 'settings'} icon={<SettingsIcon />} label="System" onClick={() => setView('settings')} />
      </nav>
    </div>
  );
}

function NavButton({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-1 transition-all",
        active ? "text-studio-accent scale-110" : "text-gray-600 opacity-60 hover:opacity-100"
      )}
    >
      <div className={cn("w-6 h-6", active && "drop-shadow-[0_0_8px_rgba(61,126,219,0.5)]")}>{icon}</div>
      <span className="text-[8px] font-black uppercase tracking-widest">{label}</span>
    </button>
  );
}
