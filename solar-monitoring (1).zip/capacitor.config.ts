import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.solarmonitoring.app',
  appName: 'Solar Monitoring',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
