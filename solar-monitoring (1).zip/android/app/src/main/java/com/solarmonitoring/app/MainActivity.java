package com.solarmonitoring.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
